export class User {
    user_name:String;
    user_password:String;
    user_email:String;
    user_mobileNumber:number;
}
